#ifndef PARTS_H
#define PARTS_H

void load_progress(double baluster_positions[][3], double square_positions[][3], int *square_index);
void save_progress(double baluster_positions[][3], double square_positions[][3], int *square_index);

#endif
