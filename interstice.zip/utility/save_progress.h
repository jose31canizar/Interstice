#ifndef PARTS_H
#define PARTS_H

void load_progress(double baluster_positions[][3], double square_positions[][3]);
void save_progress(double baluster_positions[][3]);

#endif
