#ifndef PARTS_H
#define PARTS_H

void load_initial_scene(double baluster_positions[][3]);
void generate_scene(double baluster_positions[][3], double wx, double wy, double wz);

#endif
