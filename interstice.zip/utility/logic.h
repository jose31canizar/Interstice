#ifndef LOGIC_H
#define LOGIC_H

void checker(double baluster_positions[][3], double square_positions[][3], int *square_index, double wx, double wy, double wz);

#endif
