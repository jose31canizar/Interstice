#include "collision.h"

void checker(double baluster_positions[][3], double square_positions[][3], double wx, double wy, double wz) {

        for(int i = 0; i < 16; i++) {
                generate_squares_with_detection(square_positions, wx - baluster_positions[i][0], wy, wz - baluster_positions[i][2], 0, 0);
        }

}
