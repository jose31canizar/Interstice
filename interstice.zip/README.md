# Interstice

Final Project:

##I N T E R S T I C E

Jose Canizares
CSCI4229/5229 Fall 2016

Run into the random objects and move them to the green squares on the ground to gain points.

###Instructions:

####MAC: brew install sdl2
####LINUX: apt-get install freeglut3-dev
####       apt-get install libsdl2-dev
####make
####./final


###Key Bindings
####  a         move left
####  d         move right
####  w         move forward
####  s         move backward
####  arrows    camera up, down, left, right
#### z         zoom out
####  x         zoom in
####  drag mouse horizontal   camera left or right
####  drag mouse vertical     camera up or down
####  g         grab object
####  2         save progress


####  ESC        Exit
