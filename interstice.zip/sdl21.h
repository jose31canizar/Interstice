#ifndef SDL21_H
#define SDL21_H

struct statuses {
        double wr;
        double vx;
        double vz;
} status;



#endif
