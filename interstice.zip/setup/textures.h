#ifndef TEXTURES_H
#define TEXTURES_H

unsigned int texture[7]; // Textures

#endif
