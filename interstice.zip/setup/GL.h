#ifndef GL_H
#define GL_H

#ifdef __APPLE__
#include "SDL2/SDL.h"
#include "SDL2/SDL_opengl.h"
#else
#include <SDL2/SDL.h>
#include <SDL2/SDL_opengl.h>
#endif
//#include "SDL2_mixer/SDL_mixer.h"
//#include "objects/GL.h"
// #include <OpenGl/GL.h>
// #include <gl/GLU.h>
// #include <OpenGL/gl.h>
// #include <OpenGL/glu.h>
// #include <GLUT/glut.h>

#endif
