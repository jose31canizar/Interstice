#ifndef GL_H
#define GL_H

#include <SDL2/SDL.h>
#include <SDL2/SDL_opengl.h>

#endif
