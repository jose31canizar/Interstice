#ifndef BALUSTERS_H
#define BALUSTERS_H

void draw_balusters(double wx, double wy, double wz);
void neck(double wx, double wy, double wz);
void neck2(double wx, double wy, double wz);
void neck3(double wx, double wy, double wz);
void neck4(double wx, double wy, double wz);
void baluster_1(double wx, double wy, double wz);
void baluster_2(double wx, double wy, double wz);
void baluster_3(double wx, double wy, double wz);
void baluster_4(double wx, double wy, double wz);
void baluster_5(double wx, double wy, double wz);
void baluster_6(double wx, double wy, double wz);
void baluster_7(double wx, double wy, double wz);
void baluster_8(double wx, double wy, double wz);
void baluster_9(double wx, double wy, double wz);
void baluster_10(double wx, double wy, double wz);
void baluster_11(double wx, double wy, double wz);
void baluster_12(double wx, double wy, double wz);
void baluster_13(double wx, double wy, double wz);
void baluster_14(double wx, double wy, double wz);
void baluster_15(double wx, double wy, double wz);
void baluster_16(double wx, double wy, double wz);

void balustrade(double wx, double wy, double wz);
void draw_balusters(double wx, double wy, double wz);

#endif
