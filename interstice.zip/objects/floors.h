void cube(double x,double y,double z,
          double dx,double dy,double dz,
          double th, double r, double g, double b, int tex, double range);

//, unsigned int *texture
