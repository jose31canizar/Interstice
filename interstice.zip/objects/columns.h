#ifndef COLUMNS_H
#define COLUMNS_H

void column(double x,double y,double z,
            double dx,double dy,double dz,
            double th, double h);
//draws a fluted column
void column2(double x,double y,double z,
             double dx,double dy,double dz,
             double th);

#endif
