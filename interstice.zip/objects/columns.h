#ifndef COLUMNS_H
#define COLUMNS_H

void column(double sx, double sy, double sz, double h);

void fluted_column(double x, double y, double z, double r, double fr, double height);
//draws a fluted column
void column2(double sx,double sy,double sz);

#endif
